The source project is under ./XMLProcessing

The XML, XSD, XSLT files are under ./XMLProcessing/xml/

run: java hw1.Main